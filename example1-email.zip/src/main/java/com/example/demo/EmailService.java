package com.example.demo;

import javax.mail.*;
import javax.mail.internet.*;

import org.springframework.beans.factory.annotation.*;
import org.springframework.mail.javamail.*;
import org.springframework.stereotype.Service;

@Service
public class EmailService {
	// application.properties의 설정으로 생성한 메일 전송 객체를 주입받는다 
	@Autowired
	private JavaMailSender javaMailSender;
	
	private void sendMail(String 보낸사람, String 받는사람, String 제목, String 내용) {
		MimeMessage message = javaMailSender.createMimeMessage();
		MimeMessageHelper helper;
		try {
			helper = new MimeMessageHelper(message, false, "utf-8");
			helper.setFrom(보낸사람);
			helper.setTo(받는사람);
			helper.setSubject(제목);
			// 두번째 parameter는 내용이 html로 작성되었는가?
			helper.setText(내용, true);
			javaMailSender.send(message);
		} catch (MessagingException e) {
			e.printStackTrace();
		}	
	}
	
	public void changePassword() {
		// 1. 임시비밀번호 생성
		// 2. 임시비밀번호를 db에 저장
		// 3. 이제 임시비밀번호를 이메일로 보낸다면
		String password = "aaaa1111";
		
		// 자바의 String은 상수 객체이다. 내용을 변경할 수 있는 문자열 변수는 StringBuffer나 StringBuilder를 사용한다
		String message = new StringBuffer("<p>임시비밀번호를 발급했습니다</p>").append("<p>임시비밀번호 :").
				append(password).append("</p>").toString();
		sendMail("hasaway@gmail.com", "받는사람 이메일", "임시비밀번호 안내", message);
	}
}






