package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Example1EmailApplication {

	public static void main(String[] args) {
		SpringApplication.run(Example1EmailApplication.class, args);
	}

}
