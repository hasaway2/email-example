package com.example.demo;

import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.boot.test.context.*;

@SpringBootTest
public class MailTest {
	@Autowired
	private EmailService service;
	
	@Test
	public void sendMailTest() {
		service.changePassword();
	}
}
